// ES6 module example

import { RTC } from "./RTC.mjs";    // Requires RTC.mjs file

console.log("Time via ES: " + RTC.read);


